//C libraries
#include <stdio.h>
#include <stdlib.h>
#include <string.h>//strlen(),strcpy()
#include <ctype.h> //isdigit()
#include <math.h> //sin,cos,tan, log
//Class
#include "stack.h"
#include "flag.h"
//Headers
#include "functions.cpp"
#include "arithmetic.cpp"